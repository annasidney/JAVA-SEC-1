# Java Learning Notes

A collection of beginner Java programs, transcribed from handwritten notes.
Each program is self-contained and can be compiled/run independently.

## Structure

```
java-learning-notes/
├── basics/
│   ├── PrintMessage10Times.java   # Print a message 10 times with a for loop
│   ├── PrintNumbers1to10.java     # Print numbers 1 to 10
│   └── EvenOdd.java               # Check if a user-entered number is even or odd
├── calculator/
│   └── Calculator.java            # Basic calculator (+, -, *, /, %) on two numbers
├── arrays/
│   ├── OneDArray.java             # Read and print a 1D array
│   └── TwoDArray.java             # Print a 2D (matrix) array
└── oop/
    ├── StudentDemo.java                  # Student class, fields set directly
    ├── StudentWithConstructorDemo.java   # Student class, using a constructor
    ├── CarDemo.java                      # Car class, fields set directly
    └── CarWithConstructorDemo.java       # Car class, using a constructor
```

## How to run

Each file has its own `public class` with a `main` method, so compile and run
them individually, e.g.:

```bash
cd basics
javac EvenOdd.java
java EvenOdd
```

## Notes

- `calculator/Calculator.java`: the original notebook page was cut off right
  after the two numbers were read in, so the arithmetic operations (sum,
  difference, product, quotient, remainder) were added to complete the
  program in the spirit of the notes.
- The `oop` folder shows the same `Student`/`Car` examples twice: once with
  plain field assignment, and once refactored to use a constructor, to
  illustrate the difference.
