// Code to find whether a number is even or odd
import java.util.*;

public class EvenOdd {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a no.");
        int a = sc.nextInt();

        if (a % 2 == 0) {
            System.out.println("The no. is even");
        } else {
            System.out.println("The no. is odd");
        }
    }
}
