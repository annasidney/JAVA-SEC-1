// Code to write numbers from 1 to 10
public class PrintNumbers1to10 {
    public static void main(String[] args) {
        for (int i = 1; i <= 10; i++) {
            System.out.println(i);
        }
    }
}
