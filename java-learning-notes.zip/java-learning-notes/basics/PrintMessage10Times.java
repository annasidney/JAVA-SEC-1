// Code to print a message 10 times using a for loop
public class PrintMessage10Times {
    public static void main(String[] args) {
        for (int i = 1; i <= 10; i++) {
            System.out.println("I love java");
        }
    }
}
