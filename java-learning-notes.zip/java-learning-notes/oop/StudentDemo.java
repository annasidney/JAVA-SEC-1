// Student class without a constructor
class Student {
    String name;
    int age;

    void display() {
        System.out.println("Name " + name);
        System.out.println("Age " + age);
    }
}

public class StudentDemo {
    public static void main(String[] args) {
        Student s1 = new Student();
        s1.name = "Anna";
        s1.age = 19;

        Student s2 = new Student();
        s2.name = "Ayushmaan";
        s2.age = 20;

        Student s3 = new Student();
        s3.name = "Annmann";
        s3.age = 21;

        s1.display();
        s2.display();
        s3.display();
    }
}
