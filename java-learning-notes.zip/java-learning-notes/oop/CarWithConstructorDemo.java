// Car class using a constructor
class CarWithConstructor {
    String brand;
    int price;

    CarWithConstructor(String brand, int price) {
        this.brand = brand;
        this.price = price;
    }

    void display() {
        System.out.println("Brand " + brand);
        System.out.println("Price " + price);
    }
}

public class CarWithConstructorDemo {
    public static void main(String[] args) {
        CarWithConstructor s1 = new CarWithConstructor("BMW", 10000000);
        CarWithConstructor s2 = new CarWithConstructor("Hyundai", 25000);

        s1.display();
        s2.display();
    }
}
