// Student class using a constructor
class StudentWithConstructor {
    String name;
    int age;

    StudentWithConstructor(String name, int age) {
        this.name = name;
        this.age = age;
    }

    void display() {
        System.out.println("Name " + name);
        System.out.println("Age " + age);
    }
}

public class StudentWithConstructorDemo {
    public static void main(String[] args) {
        StudentWithConstructor s1 = new StudentWithConstructor("Anna", 19);
        StudentWithConstructor s2 = new StudentWithConstructor("Maan", 21);

        s1.display();
        s2.display();
    }
}
