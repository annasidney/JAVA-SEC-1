// Car class without a constructor
class Car {
    String mileage;
    String horsepower;
    String brand;

    void display() {
        System.out.println("Mileage " + mileage);
        System.out.println("Horsepower " + horsepower);
        System.out.println("Brand " + brand);
    }
}

public class CarDemo {
    public static void main(String[] args) {
        Car s1 = new Car();
        s1.mileage = "20";
        s1.horsepower = "150";
        s1.brand = "Hyundai";

        Car s2 = new Car();
        s2.mileage = "18";
        s2.horsepower = "140";
        s2.brand = "Kia";

        s1.display();
        s2.display();
    }
}
